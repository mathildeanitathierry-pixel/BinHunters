# BinHunters — Financial & Operational Overview (Static Site)
A responsive site in dark blue & white for BinHunters (SaaS + Smart Bins and the 200KM Challenge).

## Deploy to GitHub Pages
1) Create a GitHub repo and upload these files.  
2) In **Settings → Pages**, choose **Deploy from a branch**, select **main** and **/** (root).  
3) Wait ~1 minute. Your site will be live at: `https://<user>.github.io/<repo>/`.

Contact form uses Formspree placeholder; replace the action URL with your own.
